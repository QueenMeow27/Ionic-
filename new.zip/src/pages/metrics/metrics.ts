import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the MetricsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-metrics',
  templateUrl: 'metrics.html',
})
export class MetricsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }


  
  public doughnutChartLabels:string[]=['Used Disk Space','CPU Overload ','Heap Memory','OS Memory Usage'];
  public doughnutChartData:number[]=[88,50,2,16];
  public doughnutChartType:string='doughnut';



  
  public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  
  public barChartLabels:string[] = ['Disk Spc','CPU Overload', 'Heap Memory', 'OS Memory'];
  public barChartType:string = 'bar';
  public barChartLegend:boolean = true;
  
  public barChartData:any[] = [
    {data: [5, 23, 15, 76], label: 'Process Metrics'}
   
  ];
  

  barChartColors: any [] =[
    
    {
        backgroundColor:'rgba(0,225,0.4)',
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 0.5
    }

]




  ionViewDidLoad() {
    console.log('ionViewDidLoad MetricsPage');
  }

}
