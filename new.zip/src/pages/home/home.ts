import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MetricsPage } from '../metrics/metrics';



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})



export class HomePage {

  constructor(public navCtrl: NavController) {}


openMetricsPage() {
  this.navCtrl.push(MetricsPage);
}
  

slider =[
  {
    title:'Wow Careers',
    description:'Woolworths Supermarkets Careers is where you get to register your interest in working for us. It’s also where you’ll come to review and manage job offers. ',
    image:"assets/imgs/wow.png"
  },
  {
    title:'About Us',
    description:'Whether you’re here for the first time or back to refresh your profile, this site has been built for anyone looking to become one of the Fresh Food People.',
    image:"assets/imgs/career.png"
  },
  {
    title:'Using This Site',
    description:'We are on a mission to deliver the best in convenience, value and quality for our customers. ',
    image:"assets/imgs/contact.png"
  }  
];


  }





